
alert('我是一个外部js');

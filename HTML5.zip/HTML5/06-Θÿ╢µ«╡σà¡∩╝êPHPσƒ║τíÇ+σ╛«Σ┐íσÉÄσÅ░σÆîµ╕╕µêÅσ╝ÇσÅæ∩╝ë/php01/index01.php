<html>
	<head>
		<title>第一个php文件</title>
	</head>
	<body>
		<a href="####">一个链接</a>
		<h1>h1标题</h1>
	</body>
	<script type="text/javascript">
		
	</script>
</html>
<style>
	#head{
		height: 100px;
		font-size: 30px;
		background-color: gray;
	}
</style>
<div id="head">
	头部
</div>
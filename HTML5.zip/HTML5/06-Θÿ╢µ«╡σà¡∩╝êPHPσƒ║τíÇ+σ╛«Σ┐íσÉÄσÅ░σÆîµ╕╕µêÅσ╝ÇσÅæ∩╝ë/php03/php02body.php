<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>网页</title>
	<style>
		#main{
			height: 100px;
			background-color: red;
		}
	</style>
</head>
<body>
	<?php 
		require "php02head.php";
	 ?>
	<div id="main">
		主体
	</div>
	<?php 
		require "php02foot.php";
	 ?>
</body>
</html>
<style>
	#foot{
		height: 100px;
		background-color: blue;
	}
</style>
<div id="foot">
	尾部
</div>
<script>
	
</script>
<?php 
	echo "文件引入<hr>";
 ?>
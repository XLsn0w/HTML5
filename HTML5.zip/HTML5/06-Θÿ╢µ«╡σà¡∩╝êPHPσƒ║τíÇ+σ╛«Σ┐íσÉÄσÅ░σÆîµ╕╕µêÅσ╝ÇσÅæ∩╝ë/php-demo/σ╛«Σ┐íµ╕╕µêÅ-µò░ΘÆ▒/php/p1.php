<?php 
	//echo "1111";
	session_start();
	$_SESSION['test'] = "12345";
 ?>
<?php 
	//http://ningbonuc.applinzi.com/countMoney2/php/get_openid.php
	//接口用来返回当前玩家的openid
	session_start();
	echo $_SESSION["openid"];
 ?>